
import React from 'react';
import { Spinner } from './Spinner';

interface MicButtonProps {
  isListening: boolean;
  isProcessing: boolean;
  onClick: () => void;
}

const MicButton: React.FC<MicButtonProps> = ({ isListening, isProcessing, onClick }) => {
  const buttonStateClasses = isListening
    ? 'bg-red-500 hover:bg-red-600 animate-pulse'
    : isProcessing
    ? 'bg-gray-500 cursor-not-allowed'
    : 'bg-green-500 hover:bg-green-600';

  return (
    <button
      onClick={onClick}
      disabled={isProcessing}
      className={`relative w-20 h-20 rounded-full flex items-center justify-center text-white shadow-lg transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-opacity-50 ${buttonStateClasses} ${isListening ? 'focus:ring-red-400' : 'focus:ring-green-400'}`}
    >
      {isProcessing ? (
        <Spinner />
      ) : isListening ? (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
          <path d="M5 3a5 5 0 0110 0v2a5 5 0 01-10 0V3z" />
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM4 10a6 6 0 1112 0v1a1 1 0 11-2 0v-1a4 4 0 10-8 0v1a1 1 0 11-2 0v-1z" clipRule="evenodd" />
        </svg>
      ) : (
         <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0a5 5 0 01-5 5V2.07A7.001 7.001 0 003 8a1 1 0 002 0a5 5 0 015-5v12.93z" clipRule="evenodd" />
        </svg>
      )}
    </button>
  );
};

export default MicButton;
