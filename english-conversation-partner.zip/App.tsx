import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Chat } from '@google/genai';
import { Message, Sender } from './types';
import { createChat } from './services/geminiService';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import MicButton from './components/MicButton';

// Fix: Add types for the Web Speech API to address TypeScript errors.
interface ISpeechRecognitionAlternative {
  transcript: string;
}

interface ISpeechRecognitionResult {
  readonly [index: number]: ISpeechRecognitionAlternative;
  readonly length: number;
}

interface ISpeechRecognitionResultList {
  readonly [index: number]: ISpeechRecognitionResult;
  readonly length: number;
}

interface ISpeechRecognitionEvent extends Event {
  readonly results: ISpeechRecognitionResultList;
}

interface ISpeechRecognitionErrorEvent extends Event {
  readonly error: string;
}

interface ISpeechRecognition {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  onstart: () => void;
  onend: () => void;
  onerror: (event: ISpeechRecognitionErrorEvent) => void;
  onresult: (event: ISpeechRecognitionEvent) => void;
  start: () => void;
  stop: () => void;
}

// Fix: Correctly type the SpeechRecognition constructor from the window object.
const SpeechRecognition: { new (): ISpeechRecognition } | undefined =
  (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 'initial-ai-message', text: "Hello! I'm your AI English partner. Click the microphone and let's start chatting.", sender: Sender.AI }
  ]);
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const chatRef = useRef<Chat | null>(null);
  // Fix: Use the defined ISpeechRecognition interface for the ref type.
  const recognitionRef = useRef<ISpeechRecognition | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatRef.current = createChat();
    if (!chatRef.current) {
        setError("Could not initialize AI. Please check your API key.");
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const speak = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.onend = () => setIsProcessing(false);
    utterance.onerror = (e) => {
        console.error("Speech synthesis error", e);
        setIsProcessing(false);
        setError("Sorry, I couldn't speak the response.");
    };
    window.speechSynthesis.speak(utterance);
  };
  
  const processTranscript = useCallback(async (transcript: string) => {
    if (!transcript || !chatRef.current) return;

    setIsProcessing(true);
    setMessages(prev => [...prev, { id: crypto.randomUUID(), text: transcript, sender: Sender.USER }]);

    try {
        const response = await chatRef.current.sendMessage(transcript);
        const aiText = response.text;
        
        setMessages(prev => [...prev, { id: crypto.randomUUID(), text: aiText, sender: Sender.AI }]);
        speak(aiText);

    } catch (err) {
        console.error("Error sending message to Gemini:", err);
        const errorMessage = "I'm sorry, I encountered an error. Please try again.";
        setMessages(prev => [...prev, { id: crypto.randomUUID(), text: errorMessage, sender: Sender.AI }]);
        speak(errorMessage);
        setError("Failed to get a response from the AI.");
    }
  }, []);

  const startListening = useCallback(() => {
    if (!SpeechRecognition) {
      setError("Speech recognition is not supported in your browser.");
      return;
    }
    if (isListening || isProcessing) return;

    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.continuous = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => {
        setIsListening(false);
        recognitionRef.current = null;
    };
    recognition.onerror = (event) => {
      console.error("Speech recognition error", event.error);
      setError(`Speech recognition error: ${event.error}`);
      setIsListening(false);
    };
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      processTranscript(transcript);
    };

    recognition.start();
    recognitionRef.current = recognition;
  }, [isListening, isProcessing, processTranscript]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
        recognitionRef.current.stop();
    }
  }, []);
  
  const handleMicClick = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <div className="bg-gradient-to-br from-gray-900 via-purple-900 to-gray-800 min-h-screen text-white flex flex-col font-sans">
      <Header />
      <main className="flex-1 flex flex-col p-4 overflow-hidden">
        <div className="w-full max-w-3xl mx-auto flex-1 overflow-y-auto pr-2">
            {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
            ))}
            <div ref={messagesEndRef} />
        </div>
      </main>
      <footer className="w-full max-w-3xl mx-auto p-4 flex flex-col items-center justify-center">
        {error && <p className="text-red-400 text-center mb-4">{error}</p>}
        <MicButton isListening={isListening} isProcessing={isProcessing} onClick={handleMicClick} />
        <p className="text-gray-400 mt-4 text-sm text-center">
          {isProcessing 
            ? "AI is thinking and responding..." 
            : isListening 
            ? "Listening... Click again to stop." 
            : "Click the mic to start speaking."}
        </p>
      </footer>
    </div>
  );
};

export default App;
