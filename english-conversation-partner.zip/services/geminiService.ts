
import { GoogleGenAI, Chat } from "@google/genai";

const SYSTEM_INSTRUCTION = `You are a friendly and patient English conversation partner. Your goal is to help me practice speaking English. Keep your responses concise and natural, like in a real conversation. If I make a small grammatical mistake, you can gently correct it in your response, but don't be overly critical. For example, if I say 'I goed to the store', you could reply with 'Oh, you went to the store? What did you buy?'. The main purpose is to have a flowing conversation.`;

export function createChat(): Chat | null {
  try {
    if (!process.env.API_KEY) {
      throw new Error("API_KEY environment variable not set.");
    }
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const chat: Chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
    return chat;
  } catch (error) {
    console.error("Failed to initialize Gemini AI:", error);
    return null;
  }
}
